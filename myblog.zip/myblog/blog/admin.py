from django.contrib import admin
from .models import Tipo, Post, Libro, Categoria, Enlace


# Register your models here.


admin.site.register(Tipo)

admin.site.register(Post)

@admin.register(Libro)
class LibroAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'autor', 'editorial', 'ano', 'nivel','tipo')
    search_fields = ('titulo', 'autor','tipo')
    fields = ('titulo', 'autor', 'editorial', 'ano', 'nivel', 'enlace', 'resumen', 'imagen','tipo')  # Agregar imagen

admin.site.register(Categoria)

admin.site.register(Enlace)