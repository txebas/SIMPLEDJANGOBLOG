from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from ckeditor.fields import RichTextField

from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
from ckeditor.fields import RichTextField

class Tipo(models.Model):
    nombre = models.CharField(max_length=50)

    def __str__(self):
        return self.nombre

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = RichTextUploadingField()
    created_at = models.DateTimeField(auto_now_add=True)
    tipo = models.ForeignKey(Tipo, on_delete=models.CASCADE, related_name='posts')

    def __str__(self):
        return self.title

class Libro(models.Model):
    titulo = models.CharField(max_length=255)
    autor = models.CharField(max_length=255)
    editorial = models.CharField(max_length=255)
    ano = models.PositiveIntegerField()
    nivel = models.CharField(max_length=50)
    enlace = models.URLField(max_length=200)
    resumen = RichTextField()
    imagen = models.ImageField(upload_to='libros/', blank=True, null=True)
    tipo = models.ForeignKey(Tipo, on_delete=models.CASCADE, related_name='libros')

    def __str__(self):
        return self.titulo
    
class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.nombre

class Enlace(models.Model):
    titulo = models.CharField(max_length=200)
    url = models.URLField()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE, related_name='enlaces')

    def __str__(self):
        return self.titulo
