# SIMPLEDJANGOBLOG
BLOG DJANGO 
Stack : django, ckeditor, sqlite, tailwindcss

